# ~~~~~~ Check WSUS Health ~~~~~~
# Usage - Check_WSUS_Health.ps1 

Write-Output "`n~~~~~~ Check WSUS Health for $env:COMPUTERNAME - Script executed by $env:username - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz') ~~~~~~"
Write-Output "`nWSUS Health Check"
Write-Output "---------------------------------------------------------"
cmd.exe /c "C:\Program Files\Update Services\Tools\WsusUtil.exe" CheckHealth

Write-Output "`nWeb Health Check..."
Write-Output "---------------------------------------------------------"
Write-Output "`nIIS Services"
Write-Output "---------------------------------------------------------"
Get-Service IISADMIN, WAS, W3SVC, Bits, WsusService | Format-Table -AutoSize

Write-Output "`nSite Status"
Write-Output "---------------------------------------------------------"
if((Get-Command "Get-IISSite" -ErrorAction SilentlyContinue) -ne $Null) {
	Get-IISSite | Format-Table -AutoSize
} else {
	$SiteList = c:\windows\system32\inetsrv\appcmd.exe list sites
	ForEach ($Site in $SiteList)
	{
		Write-Output $Site
	}
}

Write-Output "`nAppPool Status"
Write-Output "---------------------------------------------------------"
if((Get-Command "Get-IISAppPool" -ErrorAction SilentlyContinue) -ne $Null) {
	Get-IISAppPool | Format-Table -AutoSize
} else {
	$AppList = c:\windows\system32\inetsrv\appcmd.exe list apppools
	ForEach ($Pool in $AppList)
	{
		Write-Output $Pool
	}
}

Write-Output "`nWSUS Setup"
Write-Output "---------------------------------------------------------"
Get-Item 'Registry::HKLM\Software\Microsoft\Update Services\Server\Setup'