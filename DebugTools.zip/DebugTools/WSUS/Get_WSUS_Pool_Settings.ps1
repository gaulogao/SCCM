# ~~~~~~ Get WSUS Pool Settings ~~~~~~
# Usage - Get_WSUS_Pool_Settings.ps1

Write-Output "`n~~~~~~ Get WSUS Pool Gettings for $env:COMPUTERNAME - Script executed by $env:username - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz') ~~~~~~`n"

# Get (General) > Queue Length
Write-Output "Get (General) > Queue Length"
Write-Output "---------------------------------------------------------"
Write-Output "Get-WebConfiguration ""/system.applicationHost/applicationPools/add[@name='WsusPool']/@queueLength"""
Write-Output "Current value: ", ($(Get-WebConfiguration "/system.applicationHost/applicationPools/add[@name='WsusPool']/@queueLength")).Value

# Get Recycling > Private Virtual Memory
Write-Output "`nGet Recycling > Private Virtual Memory"
Write-Output "---------------------------------------------------------"
Write-Output "Get-WebConfiguration ""/system.applicationHost/applicationPools/add[@name='WsusPool']/recycling/periodicRestart/@privateMemory"""
Write-Output "Current value: ", ($(Get-WebConfiguration "/system.applicationHost/applicationPools/add[@name='WsusPool']/recycling/periodicRestart/@privateMemory")).Value

# Get Recycling > Regular Time Inverval (minutes)
Write-Output "`nGet Recycling > Regular Time Inverval (minutes)"
Write-Output "---------------------------------------------------------"
Write-Output "Get-WebConfiguration ""/system.applicationHost/applicationPools/add[@name='WsusPool']/recycling/periodicRestart/@time"""
Write-Output "Current value: ", ($(Get-WebConfiguration "/system.applicationHost/applicationPools/add[@name='WsusPool']/recycling/periodicRestart/@time")).Value

# Get Process Model > Idle Time-out (minutes)
Write-Output "`nGet Process Model > Idle Time-out (minutes)"
Write-Output "---------------------------------------------------------"
Write-Output "Get-WebConfiguration ""/system.applicationHost/applicationPools/add[@name='WsusPool']/processModel/@idleTimeout"""
Write-Output "Current value: ", ($(Get-WebConfiguration "/system.applicationHost/applicationPools/add[@name='WsusPool']/processModel/@idleTimeout")).Value

# Get Process Model > Ping Enabled
Write-Output "`nGet Process Model > Ping Enabled"
Write-Output "---------------------------------------------------------"
Write-Output "Get-WebConfiguration ""/system.applicationHost/applicationPools/add[@name='WsusPool']/processModel/@pingingEnabled"""
Write-Output "Current value: ", ($(Get-WebConfiguration "/system.applicationHost/applicationPools/add[@name='WsusPool']/processModel/@pingingEnabled")).Value

# Note - https://support.microsoft.com/en-us/help/4490414/windows-server-update-services-best-practices
## Queue Length = 2000 (up from default of 1000)
## Idle Time-out (minutes) = 0 (down from the default of 20)
## Ping Enabled = False (from default of True)
## Private Memory Limit (KB) = 0 (unlimited, up from the default of 1843200 KB)
## Regular Time Interval (minutes) = 0 (to prevent a recycle, and modified from the default of 1740)
