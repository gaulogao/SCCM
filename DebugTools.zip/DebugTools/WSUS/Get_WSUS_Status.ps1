# Get WSUS status:
#Note - If WSUS is configured with SSL, replace localhost with FQDN of WSUS and 8530 with the correct SSL port which is 8531 or 443 and $False with $True
# Usage - Get_WSUS_Status.ps1 <WSServer> <Port> <UseSSL?>, eg. 
#    Get_WSUS_Status.ps1 
#    Get_WSUS_Status.ps1 localhost 8530 0
#    Get_WSUS_Status.ps1 localhost 8531 1

Param(
	[Parameter(Mandatory = $false, Position = 0)][String] $WSUSServer = "localhost",
	[Parameter(Mandatory = $false, Position = 1)][Int] $Port = 8530,
	[Parameter(Mandatory = $false, Position = 2)][Int] $UseSSL = 0
)
$SSL = $False # WSUS is non-SSL by default
if($UseSSL -eq 1 -OR ((Get-ItemProperty 'Registry::HKLM\Software\Microsoft\Update Services\Server\Setup').UsingSSL)) { $SSL = $True }

# ~~~~~~ Get WSUS Status ~~~~~~
Write-Output "`n~~~~~~ Get WSUS Status for $env:COMPUTERNAME - Script executed by $env:username - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz') ~~~~~~`n"

[void][reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration")
$WSUS = [Microsoft.UpdateServices.Administration.AdminProxy]::getUpdateServer($WSUSServer, $SSL, $Port)

$WSUS.GetStatus()

Write-Output "`nWSUS Sync History"
Write-Output "---------------------------------------------------------"
$sub = $WSUS.GetSubscription()
$sub.GetSynchronizationHistory() | Format-Table