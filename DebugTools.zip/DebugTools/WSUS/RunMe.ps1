# Define the Logs directory in WSUS and result file name
$Logs = "Logs"
$ResFile = "WSUSInfo.txt"
$File = ".\WSUS\${Logs}\${ResFile}"

if (!(Test-Path ".\WSUS\${Logs}")) { New-Item -Type Directory -Name ".\WSUS\${Logs}" | Out-Null}

# Run separate PowerShell scripts to get info and print info into the same result file
.\WSUS\Check_WSUS_Health.ps1 | Out-File $File
.\WSUS\Get_WSUS_Pool_Settings.ps1 | Out-File -Append $File
.\WSUS\Get_WSUS_Status.ps1 | Out-File -Append $File
Copy-Item "C:\Program Files\Update Services\LogFiles" -Destination ".\WSUS\${Logs}" -Recurse -Force

# Copy Application event log
if (Test-Path ".\WSUS\${Logs}\Application.evtx") {Remove-Item ".\WSUS\${Logs}\Application.evtx"}
wevtutil epl Application ".\WSUS\${Logs}\Application.evtx"

# Print instructions indicating where to get the result file
Write-Host "Get all the files in DebugTools\WSUS\Logs directory" -ForegroundColor Cyan